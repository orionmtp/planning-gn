<?php
$page=5;
include 'upper2.php';
echo "<center>\n";
echo "<center>vous trouverez ici l'aide sur PlanningGN\n</center>\n";
?>