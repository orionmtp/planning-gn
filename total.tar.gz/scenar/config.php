<?php
$adresse="localhost";
$login="CG";
$password="tYr4n!de";
$database="planning";
$db = mysqli_connect( $adresse, $login, $password,$database);
?>
