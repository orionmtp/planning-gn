<?php
echo "presentation du but du site<br>\n";
echo "rien de particulier, c'est juste pour mettre la page de prez en place\n";
?>