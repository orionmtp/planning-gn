<?php
error_reporting(E_ALL);
header("Location: index.php");
die();
?>
